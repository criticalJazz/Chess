package com.example.chess.Model;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class Piece {


    private String type;
    private int y;
    private int x;
    @GeneratedValue
    @Id
    private int id;
    private boolean selected;


   /* public Piece(String typet, int xx, int yy)
    {
        type = typet;
        y = yy;
        x = xx;
        selected = false;
    }
    */


    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public String getType() {
        return type;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public boolean getSelected()
    {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}
