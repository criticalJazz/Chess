package com.example.chess.Service;


import com.example.chess.Model.Piece;
import com.example.chess.Repository.PieceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PieceService {

    @Autowired
    PieceRepository pieceRepository;

    public void save(Piece piece){
        pieceRepository.save(piece);

    }

    public void delete(Piece piece){
        pieceRepository.delete(piece);
    }

    public List<Piece> getAllPieces(){
        return pieceRepository.findAll();
    }

    public Piece fineOne(int x, int y){return pieceRepository.findByXAndY(x, y);}
}
