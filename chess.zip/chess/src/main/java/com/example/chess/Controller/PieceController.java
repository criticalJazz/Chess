package com.example.chess.Controller;


import com.example.chess.Model.Piece;
import com.example.chess.Service.PieceService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:8000")
public class PieceController {

    private PieceService pieceService;

    public PieceController(PieceService pieceService)
    {
        this.pieceService = pieceService;
    }


    @RequestMapping(value = "/chess", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Piece> getAllPieces(){
        return pieceService.getAllPieces();

    }

    @RequestMapping(value = "/chess/{x}/{y}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Piece findPiece(@PathVariable int x, @PathVariable int y){
        return pieceService.fineOne(x, y);

    }
}
