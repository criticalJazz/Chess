package com.example.chess.Repository;


import com.example.chess.Model.Piece;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PieceRepository extends JpaRepository<Piece, Integer> {


    <S extends Piece> S save(S s);

    Piece findByXAndY(int x, int y);

    @Override
    void delete(Piece piece);

    List<Piece> findAll();


}
